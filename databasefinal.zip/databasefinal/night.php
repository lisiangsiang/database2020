<?php
include("connect.php");  //連結資料庫
session_start();
$account = $_SESSION['account'];      //post獲取表單裡的account
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>返台。</title>
    <link rel="stylesheet" href="background.css">
    <script src="night_chooseAttraciton.js"></script>
</head>

<body>
    <div class="background">

        <?php
        $sql1 = "SELECT * FROM Getattraction WHERE Account='$account'";
        $result1 = mysqli_query($link, $sql1) or die("fail sent");
        $totalGo_attraction = mysqli_num_rows($result1);                     #判斷使用者去了幾個景點

        $sql2 = "SELECT * FROM Sightseeing";
        $result2 = mysqli_query($link, $sql2) or die("fail sent");
        $totalattraction = mysqli_num_rows($result2);                                       #判斷景點資料表裡面共有幾筆資料

        if ($totalGo_attraction < 4) {                                                      #if ($totalGo_attraction<$totalattraction)
            include("taiwain.php");
        } else {
            echo '<script>console.log("你已經去過' . $totalGo_attraction . '個景點")</script>';

            $sql = "SELECT * FROM Userchoice NATURAL JOIN Puzzle WHERE Account='$account' AND User_answer=Answer ";
            $result = mysqli_query($link, $sql) or die("fail sent10");
            $all = mysqli_num_rows($result);                                                #判斷使用者有哪些是答對的!

            echo '<script>console.log("你答對了' . $all . '個題目")</script>';

            if ($all > 2) {                                                                   #if ($totalitem > 我自訂要拿到的道具數目 )
                header("refresh:0;url=gameover(S).html");
                exit;
            } else {
                header("refresh:0;url=gameover(F).html");
                exit;
            }
        }
        ?>
        <div style="position: relative; top:-100% ; left:0%">
            <?php
            include("notebook.php");
            ?>
        </div>

    </div>
</body>

</html>