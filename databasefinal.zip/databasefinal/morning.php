<?php
include("connect.php");
$item_memory = $_POST['item_name'];
session_start();
$account = $_SESSION['account'];
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>返台。</title>
    <link rel="stylesheet" href="background.css">
    <script src="night_chooseAttraciton.js"></script>


</head>

<body>
    <div class="background">
        <?php
        include("notebook.php");
        ?>
        <div id="morning" class="morning">
            <!--白天(小朋友在哭)背景圖片-->
            <img src="image/background/morning.jpg" class="backgroundImg">
            <div>
                <!--要放記憶碎片的文字框-->
                <?php
                $sql = "SELECT Memory FROM Item where Item_name='$item_memory'";
                $result = mysqli_query($link, $sql) or die("fail sent");
                $row = mysqli_fetch_array($result);
                $row_num = mysqli_num_rows($result);
                if ($row_num == 1)     //如果答對題目,而且題目有道具的話
                {
                    echo '
                    <div class="textarea">
                    <p id="memory_word">' . $row['Memory'] . '</p>
                    <form action="night.php">
                    <input class="Go_night_button" type=submit value="回到晚上">
                    </form>
                    </div>';
                } else {    //如果答對題目,但是題目沒有道具的話
                    echo '
                    <div class="textarea">
                    <p id="memory_word">你有答對題目,但是你什麼東西都沒有得到:(</p>
                    <form action="night.php">
                    <input class="Go_night_button" type=submit value="回到晚上">
                    </form>
                    </div>';
                }

                ?>
            </div>
        </div>
    </div>
</body>

</html>