<?php
    include("connect_database.php");
    $District=@$_POST['District'];
    $Town=@$_POST['Town'];
    $Attraction=@$_POST['Attraction'];
    $Description=@$_POST['Description'];
    $Address=@$_POST['Address'];
    $Item_name=@$_POST['Item'];
    $Memory=@$_POST['Memory'];
    $Picture=@$_POST['Picture'];
    mysqli_options($link,MYSQLI_OPT_INT_AND_FLOAT_NATIVE,true);

    $sql="SELECT Postal From Township  WHERE `Town`='{$_POST['Town']}'";
    $result=mysqli_query($link,$sql);
    $row=mysqli_fetch_assoc($result);
    $Postal= $row['Postal'];
    
   

?>



<?php
        if (((@$_FILES["file"]["type"] == "image/gif")
            || (@$_FILES["file"]["type"] == "image/jpeg")
            || (@$_FILES["file"]["type"] == "image/jpg"))
         ) {
            if ($_FILES["file"]["error"] > 0) {
                echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
            } else {
            //設定檔案上傳路徑，選擇指定資料夾

                if (file_exists("Image/Picture/" . $_FILES["file"]["name"])) {
                    echo $_FILES["file"]["name"] . " already exists. ";
                } else {
                    move_uploaded_file(
                        $_FILES["file"]["tmp_name"],
                        "Image/Picture/" . $_FILES["file"]["name"]
                    );
                    
                }
            }
        } else {
            echo "圖片上傳失敗！";//上傳失敗後顯示錯誤資訊
        }

        ?>

        <?php
            if($Attraction!=NULL)
            {
                $sql_Sightseeing = "INSERT INTO Sightseeing
                (Postal,Attraction,Picture,Description,Address) 
                VALUES ('$Postal','$Attraction','$Picture','$Description','$Address')";

                mysqli_select_db( $link, 'Sightseeing' );
                $retval_Sightseeing = mysqli_query( $link, $sql_Sightseeing );
                if(! $retval_Sightseeing )
                {
                die('無法新增景點: ' . mysqli_error($link));
                }
                echo "景點新增成功   ";
            }
            else{
                echo"<p>Null 你有東西沒輸入</p><br>";
            }
            






            if($Item_name!=NULL&&$Attraction!=NULL)
            {
                $sql_item = "INSERT INTO Item 
                (Item_name,Memory,Attraction) 
                VALUES ('$Item_name','$Memory','$Attraction')";

                mysqli_select_db( $link, 'Item' );
                $retval_item = mysqli_query( $link, $sql_item );
                if(! $retval_item ){
                    die('無法新增道具: ' . mysqli_error($link));
                }
                echo "道具新增成功    <br>";

            }
            else{
                echo"<p>新增道具失敗</p><br>";
            }
            
            
        ?>

<form action="delete_table.php" method="post">
    <input type="hidden" name="choose_table" value="Sightseeing">
    <input type='submit' value='回到上一頁' onclick="javascript:location.href='delete_table.php'">

</form>