<?PHP
header("Content-Type: text/html; charset=utf8");
include('connect.php'); //連結資料庫

session_start();
$_SESSION['account'] = $_POST['account'];
$account = $_SESSION['account'];      //post獲取表單裡的account
$password1 = $_POST['password1']; //post獲取表單裡的password

if ($account != NULL && $password1 != NULL) { //如果使用者名稱和密碼都不為空
    $sql1 = "SELECT * FROM User WHERE `Account` = '$account' AND `Password`='$password1'"; //檢測資料庫是否有對應的username和password的sql
    $result1 = mysqli_query($link, $sql1); //執行sql
    $rows = mysqli_num_rows($result1); //返回資料數(0或1)

    $sql2="SELECT * FROM User WHERE `Account` = '$account'";
    $result2 = mysqli_query($link, $sql2); //執行sql
    $account_num= mysqli_num_rows($result2);


    if ($rows) { //如果存在此帳號,且密碼正確
        $update_state = "UPDATE User SET `Online` = 1 WHERE `Account` = '$account'";
        $result1 = mysqli_query($link, $update_state);
        echo "<script>alert('登入成功!!')</script>";
        header("refresh:0;url=morning_first.html"); //如果成功跳轉至welcome.html頁面
        exit;
    } else if(!$account_num)        //如果不存在此帳號
    {
        echo "<script>alert('不存在此帳號!再重新輸入一次!!')</script>";
        header("refresh:0;url=signin.html");
        exit;
        
    }
    else   //如果存在此帳號,但是密碼錯誤
    {
        echo "<script>alert('密碼錯誤!再重新輸入一次!!')</script>";
        header("refresh:0;url=signin.html");
        exit;
    }
} else { //如果使用者名稱或密碼有空
    echo "<script>alert('表單填寫不完整!再重新輸入一次!!')</script>";
    header("refresh:0;url=signin.html");
    exit;

}

mysqli_close($link); //關閉資料庫
