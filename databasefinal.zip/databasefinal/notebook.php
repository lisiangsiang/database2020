<div class="scene">
    <!--開啟筆記本後-->
    <div class="book">
        <img id="notebook" src="image/notebook/notebook.png" class="notebookIcon makePointer " onclick="openNotebook()">
        <div class="notebook" id="innerNotebook">
            <!--筆記本內頁-->
            <img src="image/notebook/notebook_page.png" id="notebook_page" class="notebook_page">

            <?php
            $sql = "SELECT Attraction FROM Getattraction WHERE Account='$account'";
            $result1 = mysqli_query($link, $sql);
            $pages = mysqli_num_rows($result1);         #計算現在玩家去過幾個景點
            $ATTRACTION = array();

            $sql = "SELECT `Description` FROM Getattraction NATURAL JOIN Sightseeing WHERE Account='$account'";
            $result2 = mysqli_query($link, $sql);
            $DESCRIPTION = array();

            $sql = "SELECT `District` FROM Getattraction NATURAL JOIN Sightseeing NATURAL JOIN Township WHERE Account='$account'";
            $result7 = mysqli_query($link, $sql);
            $DISTRICT = array();

            $sql = "SELECT `Town` FROM Getattraction NATURAL JOIN Sightseeing NATURAL JOIN Township WHERE Account='$account'";
            $result8 = mysqli_query($link, $sql);
            $TOWN = array();

            $sql = "SELECT `Address` FROM Getattraction NATURAL JOIN Sightseeing WHERE Account='$account'";
            $result3 = mysqli_query($link, $sql);
            $ADDRESS = array();

            $sql = "SELECT `Picture` FROM Getattraction NATURAL JOIN Sightseeing WHERE Account='$account'";
            $result4 = mysqli_query($link, $sql);
            $PICTURE = array();

            $sql = "SELECT Item_name FROM Getitem WHERE Account='$account'";
            $result5 = mysqli_query($link, $sql);
            $items = mysqli_num_rows($result5);         #計算現在玩家得到幾個道具
            $ITEM = array();

            $sql = "SELECT Memory FROM Getitem NATURAL JOIN Item WHERE Account='$account'";
            $result6 = mysqli_query($link, $sql);
            $MEMORY = array();

            for ($i = 0; $i < $pages; $i++) {           #另外存成一個可以用索引值的陣列
                if ($pages > 0) {           #如果有去過景點了,就創別的陣列存
                    $attraction = mysqli_fetch_array($result1);
                    $description = mysqli_fetch_array($result2);
                    $district = mysqli_fetch_array($result7);
                    $town = mysqli_fetch_array($result8);
                    $address = mysqli_fetch_array($result3);
                    $picture = mysqli_fetch_array($result4);
                    array_push($ATTRACTION, "$attraction[Attraction]");
                    array_push($DESCRIPTION, "$description[Description]");
                    array_push($DISTRICT, "$district[District]");
                    array_push($TOWN, "$town[Town]");
                    array_push($ADDRESS, "$address[Address]");
                    array_push($PICTURE, "image/picture/$picture[Picture]");    #直接把PICTURE[]的值存成圖片路徑
                }
            }

            for ($i = 0; $i < $items; $i++) {           #另外存成一個可以用索引值的陣列
                if ($items > 0) {           #如果有得到道具了,就創別的陣列存
                    $item = mysqli_fetch_array($result5);
                    $memory = mysqli_fetch_array($result6);
                    array_push($ITEM, "$item[Item_name]");
                    array_push($MEMORY, "$memory[Memory]");
                }
            }
            ?>

            <!--顯示景點/道具名稱-->
            <div class="notebook_title" id="attraction"></div>
            <!--顯示景點描述/記憶碎片-->
            <div class="notebook_description">
                <div style="width:325px;" id="description"></div>
            </div>
            <!--顯示景點地址-->
            <div class="notebook_address" id="address"></div>
            <!--顯示景點圖片-->
            <div id="notebook_pic" style="position:absolute; margin-top: -63%; margin-left: 7%;"></div>

            <!--景點的上一頁-->
            <img src="image/notebook/last_page.png" id="last_page_attraction" class="makePointer last_page" onclick="lastpage_attraction()">
            <!--景點的下一頁-->
            <img src="image/notebook/next_page.png" id="next_page_attraction" class="makePointer next_page" onclick="nextpage_attraction()">
            <!--道具的上一頁-->
            <img src="image/notebook/last_page.png" id="last_page_item" class="makePointer last_page" onclick="lastpage_item()">
            <!--道具的下一頁-->
            <img src="image/notebook/next_page.png" id="next_page_item" class="makePointer next_page" onclick="nextpage_item()">
            <!--藍色標籤(切換景點頁)-->
            <img src="image/notebook/bookmark_visit.png" id="bookmark_visit" class="makePointer bookmark_visit" onclick="initial_attraction()">
            <div id="title_attraction" class="title">
                ・attraction
            </div>
            <!--紅色標籤(切換道具頁)-->
            <img src="image/notebook/bookmark_item.png" id="bookmark_item" class="makePointer bookmark_item" onclick="initial_item()">
            <div id="title_item" class="title">
                ・item
            </div>
            <!--關閉筆記本-->
            <img src="image/notebook/cancel.png" onclick="closeNotebook()" id="cancel" class="makePointer cancel">

            <script>
                var pages = <?php echo $pages; ?>;
                var items = <?php echo $items; ?>;
                var page = 0;
                var item = 0;
                console.log("有 " + pages + " 個景點");
                console.log("有 " + items + " 個道具");

                if (pages > 0) {
                    var Attraction = new Array(pages);
                    var Description = new Array(pages);
                    var District = new Array(pages);
                    var Town = new Array(pages);
                    var Address = new Array(pages);
                    var Picture = new Array(pages);
                }
                if (items > 0) {
                    var Item = new Array(pages);
                    var Memory = new Array(pages);
                }

                if (pages > 0) {
                    Attraction = <?php echo json_encode($ATTRACTION); ?>;
                    Description = <?php echo json_encode($DESCRIPTION); ?>;
                    District = <?php echo json_encode($DISTRICT); ?>;
                    Town = <?php echo json_encode($TOWN); ?>;
                    Address = <?php echo json_encode($ADDRESS); ?>;
                    Picture = <?php echo json_encode($PICTURE); ?>;
                    console.log(Attraction);
                } else {
                    console.log('還沒去過任何景點.');
                }

                if (items > 0) {
                    Item = <?php echo json_encode($ITEM); ?>;
                    Memory = <?php echo json_encode($MEMORY); ?>;
                    console.log(Item);
                } else {
                    console.log('還沒得到任何道具.');
                }

                var attraction = document.getElementById("attraction");
                var description = document.getElementById("description");
                var address = document.getElementById("address");
                var notebook_pic = document.getElementById("notebook_pic");

                initial_attraction();
                document.getElementById("innerNotebook").style.display = "none"; //一開始不顯示

                /*初始景點頁面*/
                function initial_attraction() {
                    if (pages == 0) {
                        attraction.innerHTML = "你哪裡都沒去過!";
                        description.innerHTML = "";
                        address.innerHTML = "";
                        notebook_pic.innerHTML="";
                    } else {
                        attraction.innerHTML = "景點名稱: " + Attraction[0] + "";
                        description.innerHTML = "景點描述:<br>" + Description[0] + "";
                        address.innerHTML = "地址:<br>" + District[0] + "" + Town[0] + "" + Address[0] + "";
                        notebook_pic.innerHTML="<img src="+Picture[0]+" class='notebook_pic'>";
                    }

                    document.getElementById("bookmark_visit").style.marginTop = "1.3%"; //將藍色書籤(景點),位置設在下面(點下去的狀態)
                    document.getElementById("bookmark_item").style.marginTop = "-1%"; //將紅色書籤(道具),位置設在上面(未點下去的狀態)
                    document.getElementById("title_attraction").style.display = ""; //顯示・attraction字樣
                    document.getElementById("title_item").style.display = "none"; //隱藏・item字樣
                    document.getElementById("last_page_item").style.display = "none"; //隱藏道具的上一頁
                    document.getElementById("next_page_item").style.display = "none"; //隱藏道具的下一頁
                    document.getElementById("last_page_attraction").style.display = ""; //顯示景點的上一頁
                    document.getElementById("next_page_attraction").style.display = ""; //顯示景點的下一頁
                    item = 0;
                }

                /*景點的下一頁*/
                function nextpage_attraction() {
                    if (page < pages - 1 && pages > 0) {
                        page = page + 1;
                        attraction.innerHTML = "景點名稱: " + Attraction[page] + "";
                        description.innerHTML = "景點描述:<br>" + Description[page] + "";
                        address.innerHTML = "地址:<br>" + District[page] + "" + Town[page] + "" + Address[page] + "";
                        notebook_pic.innerHTML="<img src="+Picture[page]+" class='notebook_pic' >";
                    }
                }

                /*景點的上一頁*/
                function lastpage_attraction() {
                    if (page > 0) {
                        page = page - 1;
                        attraction.innerHTML = "景點名稱: " + Attraction[page] + "";
                        description.innerHTML = "景點描述:<br>" + Description[page] + "";
                        address.innerHTML = "地址:<br>" + District[page] + "" + Town[page] + "" + Address[page] + "";
                        notebook_pic.innerHTML="<img src="+Picture[page]+" class='notebook_pic'>";
                    }
                }

                /*初始道具頁面*/
                function initial_item() {

                    //判斷現在有沒有任何道具
                    if (items == 0) { //如果沒有
                        attraction.innerHTML = "你還沒有任何道具!";
                        description.innerHTML = "";
                        address.innerHTML = "";
                        notebook_pic.innerHTML="";

                    } else { //如果有
                        attraction.innerHTML = "道具名稱: " + Item[0] + "";
                        description.innerHTML = "記憶碎片:<br>" + Memory[0] + "";
                        address.innerHTML = "";
                        notebook_pic.innerHTML="";
                    }

                    document.getElementById("bookmark_item").style.marginTop = "1.3%"; //將紅色書籤(道具),位置設在下面(點下去的狀態)
                    document.getElementById("bookmark_visit").style.marginTop = "-1%"; //將藍色書籤(景點),位置設在上面(未點下去的狀態)
                    document.getElementById("title_item").style.display = ""; //顯示・item字樣
                    document.getElementById("title_attraction").style.display = "none"; //隱藏・attraction字樣
                    document.getElementById("last_page_item").style.display = ""; //顯示道具的上一頁
                    document.getElementById("next_page_item").style.display = ""; //顯示道具的下一頁
                    document.getElementById("last_page_attraction").style.display = "none"; //隱藏景點的上一頁
                    document.getElementById("next_page_attraction").style.display = "none"; //隱藏景點的下一頁
                    page = 0;
                }

                /*道具的下一頁*/
                function nextpage_item() {
                    if (item < items - 1 && items > 0) {
                        item = item + 1;
                        attraction.innerHTML = "道具名稱: " + Item[item] + "";
                        description.innerHTML = "記憶碎片:<br>" + Memory[item] + "";
                        address.innerHTML = "";
                        notebook_pic.innerHTML="";
                    }
                }

                /*道具的上一頁*/
                function lastpage_item() {
                    if (item > 0) {
                        item = item - 1;
                        attraction.innerHTML = "道具名稱: " + Item[item] + "";
                        description.innerHTML = "記憶碎片:<br>" + Memory[item] + "";
                        address.innerHTML = "";
                        notebook_pic.innerHTML="";
                    }
                }

                /*關閉筆記本,重置原本翻的頁數*/
                function closeNotebook() {
                    page = 0;
                    item = 0;
                    document.getElementById("innerNotebook").style.display = "none"; //一開始不顯示
                }


                function openNotebook() {
                    document.getElementById("innerNotebook").style.display = "";
                    initial_attraction();
                }
            </script>
        </div>
    </div>
</div>