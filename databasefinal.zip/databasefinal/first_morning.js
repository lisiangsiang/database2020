function initial(){
    document.getElementById("start2").style.display="none";
    document.getElementById("start3").style.display="none";
    document.getElementById("start4").style.display="none";
    document.getElementById("start5").style.display="none";
    document.getElementById("start6").style.display="none";
    document.getElementById("start7").style.display="none";
    document.getElementById("start8").style.display="none";
}

function start1(){
    document.getElementById("start1").style.display="none";
    document.getElementById("start2").style.display="";
}

function start2(){
    document.getElementById("start2").style.display="none";
    document.getElementById("start3").style.display="";
}

function start3(){
    document.getElementById("start3").style.display="none";
    document.getElementById("start4").style.display="";
}

function start4(){
    document.getElementById("start4").style.display="none";
    document.getElementById("start5").style.display="";
}

function start5(){
    document.getElementById("start5").style.display="none";
    document.getElementById("start6").style.display="";
}

function start6(){
    document.getElementById("start6").style.display="none";
    document.getElementById("start7").style.display="";
}

function start6(){
    document.getElementById("start7").style.display="none";
    document.getElementById("start8").style.display="";
}

window.addEventListener("load",initial,false);
