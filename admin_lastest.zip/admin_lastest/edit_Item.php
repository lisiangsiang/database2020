

<?php
    include("connect_database.php");
    if($_GET['edit']!=NULL)
    {
        $sql="SELECT * FROM Item WHERE Item_name='{$_GET['edit']}'";
        $sql_getattraction="SELECT Attraction FROM Sightseeing";
        $result=mysqli_query($link,$sql);
        $result_attraction=mysqli_query($link,$sql_getattraction);
        $row=mysqli_fetch_array($result);
    }
?>
<!DOCTYPE html>
<head>
    <meta charset = "UTF-8">
    <title>edit_item</title>
    <link rel="stylesheet" href="background.css">
    <script> 
        function check(){
            var con =  confirm('確定送出？');
            if(con==true){
                return true;
            }
            else {
                return false;
            }
        };
    </script>
    </script>
      <style type="text/css">
        *{
            justify-content:center;
            align-items:center;
            width:auto;
        }
        p,input,textarea,select{
            margin:10px;
            color: black;
            margin-top: 1%;
            font-family: sans-serif, "poppins";
            font-size: 17px;
        }

    </style>
</head>
<body>
    <form action="update_item.php" method="post">
        <input type="hidden"  value="<?php echo $row['Item_name'];?>" name="origin_item">
        <p>道具名稱 :</p>
        <input name="new_Item_name" value="<?php echo $row['Item_name'];?>">
        <p>記憶碎片 :</p>
        <textarea name="new_Memory" style='width:450px;height:80px'><?php echo $row['Memory'];?></textarea>

        <!--input name="new_Memory" value="<?php echo $row['Memory'];?>"-->
        <p>景點名稱<select name="new_Attraction" ></p>
        <option value="<?php echo $row['Attraction'];?>"> 原：<?php echo $row['Attraction'];?></option>
        <?php while($row_attraction=mysqli_fetch_array($result_attraction) )
        {
            echo "<option value='{$row_attraction['Attraction']}'>{$row_attraction['Attraction']}</option>";
        } 
        ?>
        <input type="submit" value="送出" onclick='return check()'>
    </form>
</body>
</html>
