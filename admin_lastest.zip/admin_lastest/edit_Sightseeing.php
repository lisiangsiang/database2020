

<?php
    include("connect_database.php");
    if($_GET['edit']!=NULL)
    {
        $sql="SELECT * FROM Sightseeing WHERE Attraction='{$_GET['edit']}'";
        $sql_Postal="SELECT Postal FROM Township ORDER BY Postal";
        $result=mysqli_query($link,$sql);
        $result_Postal=mysqli_query($link,$sql_Postal);
        $row=mysqli_fetch_array($result);
    }
?>
<!DOCTYPE html>
<head>
    <meta charset = "UTF-8">
    <title>edit_Sightseeing</title>
    <script> 
        function check(){
            var con =  confirm('確定送出？');
            if(con==true){
                return true;
            }
            else {
                return false;
            }
        };
    </script>
    <link rel="stylesheet" href="background.css">
      <style type="text/css">
        *{
            justify-content:center;
            align-items:center;
            width:auto;
        }
        p,input,textarea,img{
            margin:10px;
            color: black;
            margin-top: 1%;
            font-family: sans-serif, "poppins";
            background-color:wheat;
            font-size: 17px;
        }
        img{
            width:300px;
        }


    </style>
</head>
<body>
    
    <form action="update_Sightseeing.php" method="post" align="center>
        <input type="hidden"  value="<?php echo $row['Postal'];?>" name="origin_Postal">
        <input type="hidden"  value="<?php echo $row['Attraction'];?>" name="origin_Attraction">
        <p>郵遞區號 : <select name="new_Postal" ></p>
        <option value="<?php echo $row['Postal'];?>"> 原：<?php echo $row['Postal'];?></option>
        <?php while($row_Postal=mysqli_fetch_array($result_Postal) )
        {
            echo "<option value='{$row_Postal['Postal']}'>{$row_Postal['Postal']}</option>";
        } 
        ?>
        <p>排版<select name="" ></p>
        <p>景點名稱 : <input type='text' name="new_Attraction" value="<?php echo $row['Attraction'];?>"></p>
        <p>照片網址 : <input type='text' name="new_Picture" value="<?php echo $row['Picture'];?>"style='width:420px'></p>
        <p>照片：</p><img src="Picture/<?php echo $row['Picture'];?>">
        <!--<p>景點介紹<input type='text' name="new_Description" value="<?php echo $row['Description'];?>" style='width:500px;height:500px'></p>
    --> <p>景點介紹 : </p><textarea  name="new_Description"  style='width:500px;height:120px'><?php echo $row['Description'];?></textarea>
        <p>景點地址 : <input type='text' name="new_Address" value="<?php echo $row['Address'];?>" style='width:350px'></p>
        <input type="submit" value="送出" onclick='return check()'>
    </form>
</body>
</html>
