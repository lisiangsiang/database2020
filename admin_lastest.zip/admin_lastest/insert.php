<!DOCTYPE html>
<html>
    <body>
        <p>請選擇要操作的表格</p>
        <form action='delete_table.php' method='post'>
        <select name="choose_table">
        <option value='NULL'>---請選擇表格---</option>
        <option value='item' name='Item'>道具</option>
        <option value='Sightseeing'>景點</option>
        <option value='Puzzle'>謎題</option>
        <option value='Township'>鄉鎮市區</option>
        <input type='submit' name='確定' onclick="javascript:location.href='delete_table.php'">
        </form>
    </body> 

</html>
