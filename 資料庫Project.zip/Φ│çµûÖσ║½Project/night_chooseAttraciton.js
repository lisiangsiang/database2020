
function normalTaiwan() {
    var img = document.getElementById("taiwan");
    img.setAttribute("src", "image/taiwan/taiwan.png");

}

function deepTaiwan(location) {

    var img = document.getElementById("taiwan");
    if (location == 新北市) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_新北市.png");
    }
    else if (location == 台北市) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_台北市.png");
    }
    else if (location == 基隆市) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_基隆市.png");
    }
    else if (location == 宜蘭縣) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_宜蘭縣.png");
    }
    else if (location == 桃園市) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_桃園市.png");
    }
    else if (location == 新竹縣) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_新竹縣.png");
    }
    else if (location == 苗栗縣) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_苗栗縣.png");
    }
    else if (location == 台中市) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_台中市.png");
    }
    else if (location == 彰化縣) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_彰化縣.png");
    }
    else if (location == 雲林縣) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_雲林縣.png");
    }
    else if (location == 南投縣) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_南投縣.png");
    }
    else if (location == 花蓮縣) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_花蓮縣.png");
    }
    else if (location == 嘉義縣) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_嘉義縣.png");
    }
    else if (location == 嘉義市) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_嘉義市.png");
    }
    else if (location == 台南市) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_台南市.png");
    }
    else if (location == 高雄市) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_高雄市.png");
    }
    else if (location == 屏東縣) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_屏東縣.png");
    }
    else if (location == 台東縣) {
        img.setAttribute("src", "image/taiwan/按下去的效果/taiwan_台東縣.png");
    }
}


