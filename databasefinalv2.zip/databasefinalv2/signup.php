<?php

header("Content-Type: text/html; charset=utf8");
include('connect.php'); //連結資料庫

$account = $_POST['account1']; //post獲取表單裡的account
$password = $_POST['password2']; //post獲取表單裡的password
$password_check = $_POST['password3'];

if ($account != NULL && $password != NULL && $password_check != NULL) //如果值不為空
{
    $sql = "SELECT * FROM User WHERE `Account` = '$account'"; //檢測User中是否有重複的Account
    $result = mysqli_query($link, $sql); //執行sql
    $rows = mysqli_num_rows($result); //返回Account一樣的資料數(0或1)

    if ($password == $password_check) { //如果密碼跟確認密碼輸入的一樣
        if (!$rows) { //如果相同的資料數為0

            $add_account = "INSERT INTO User(Account,Password,Online) VALUES ('$account','$password',0)";
            $reslut = mysqli_query($link, $add_account);
            echo "<script>alert('歡迎 '$account' 加入!!')</script>";                    //!!!!!!!!!!!顯示不出來!!!!!!!!!!!!!!                          
            header("refresh:0;url=signin.html");//如果成功,跳轉至signin.html頁面
            exit;
        } else {
            echo "<script>alert('已有重複帳號名稱!!再重新輸入一次!!')</script>";
            header("refresh:0;url=signup.html");
            exit;
        }
    } else {
        echo "<script>alert('兩個密碼輸入的不一樣啦!!再重新輸入一次!!')</script>";
        header("refresh:0;url=signup.html");
        exit;
    }
} else { //如果值有空
    echo "<script>alert('表單填寫不完整!再重新輸入一次!!')</script>";
    header("refresh:0;url=signup.html");
    exit;
}

mysqli_close($link);
