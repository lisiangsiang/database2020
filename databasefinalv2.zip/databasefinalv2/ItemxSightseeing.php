
<p><a href="insert.php">返回選擇頁</a><p>
<p><a href="insertItemxSightseeing.php">前往新增景點＆道具</a></p>

<?php
include("connect_database.php");
$sql="SELECT * From Township natural join Sightseeing natural join Item order by Postal";
$result=mysqli_query($link,$sql);
echo"<table border=3 id='content2_sightseeing'>";
echo"<tr><td>所在區域</td><td>景點名稱</td><td>照片</td><td>景點描述</td><td>景點地址</td><td>道具名稱</td><td>記憶碎片</td><td>功能</td></tr>";
while($row=mysqli_fetch_array($result))
{
    echo "<tr><td>{$row['District']}{$row['Town']}</td>
              <td>{$row['Attraction']}</td>
              <td><img src='{$row['Picture']}'></td>
              <td>{$row['Description']}</td>
              <td>{$row['Address']}</td>
              <td>{$row['Item_name']}</td>
              <td>{$row['Memory']}</td>
              <td><a href='delete_Sightseeing.php?del={$row['Attraction']}'>delete</a>
              </td></tr>";
}
echo "</table>";

?>
