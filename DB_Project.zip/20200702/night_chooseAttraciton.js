
function normalTaiwan() {
    var img = document.getElementById("taiwan");
    img.setAttribute("src", "image/taiwan/taiwan.png");

}

function deepTaiwan(location) {

    var img = document.getElementById("taiwan");
    if (location == 新北市) {
        img.setAttribute("src", "image/taiwan/show/taiwan_newtaipei.png");
    }
    else if (location == 台北市) {
        img.setAttribute("src", "image/taiwan/show/taiwan_taipei.png");
    }
    else if (location == 基隆市) {
        img.setAttribute("src", "image/taiwan/show/taiwan_keelung.png");
    }
    else if (location == 宜蘭縣) {
        img.setAttribute("src", "image/taiwan/show/taiwan_yilan.png");
    }
    else if (location == 苗栗縣) {
        img.setAttribute("src", "image/taiwan/show/taiwan_miaoli.png");
    }
    else if (location == 台中市) {
        img.setAttribute("src", "image/taiwan/show/taiwan_taichung.png");
    }
    else if (location == 彰化縣) {
        img.setAttribute("src", "image/taiwan/show/taiwan_changhua.png");
    }
    else if (location == 雲林縣) {
        img.setAttribute("src", "image/taiwan/show/taiwan_yunlin.png");
    }
    else if (location == 南投縣) {
        img.setAttribute("src", "image/taiwan/show/taiwan_nantou.png");
    }
    else if (location == 花蓮縣) {
        img.setAttribute("src", "image/taiwan/show/taiwan_hualien.png");
    }
    else if (location == 台南市) {
        img.setAttribute("src", "image/taiwan/show/taiwan_tainan.png");
    }
    else if (location == 高雄市) {
        img.setAttribute("src", "image/taiwan/show/taiwan_kaohsiung.png");
    }
    else if (location == 屏東縣) {
        img.setAttribute("src", "image/taiwan/show/taiwan_pingtung.png");
    }
    else if (location == 台東縣) {
        img.setAttribute("src", "image/taiwan/show/taiwan_taitung.png");
    }
}


