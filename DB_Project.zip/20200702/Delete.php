<?php
include("connect.php");  //連結資料庫
session_start();
$account = $_SESSION['account'];      //post獲取表單裡的account
?>

<?php   
    if($_POST["userchoice"]==1)
    {
        $sql1 = "Delete FROM `Getitem` WHERE `Account`='$account'";
        $result1 = mysqli_query($link,$sql1) or die("fail sent");

        $sql2 = "Delete FROM `Getattraction` WHERE `Account`='$account'";
        $result2 = mysqli_query($link,$sql2) or die("fail sent");

        header("Location:http://localhost/20200702/Start.html");
        exit;
    }
    else{
        header("Location:http://localhost/20200702/Start.html");
        exit;
    }
?>
