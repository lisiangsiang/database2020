<div id="night" class="night">
    <!--星星背景圖片-->
    <img src="image/background/night.jpg" class="backgroundImg">
    <div>
        <!--台灣圖片-->
        <img src="image/taiwan/taiwan.png" class="taiwan" id="taiwan">
    </div>
    <!--地名(景點)選單-->
    <div class="option">
        <form action="intro.php" method="post">
            <!--北部(黃色區塊)-->
            <div class="northArea">
                <!--行政區名稱-->
                <nav id="基隆市" onmouseover="deepTaiwan(基隆市)" onmouseout="normalTaiwan()">基隆市
                    <ul>
                        <!--該行政區的景點選項-->
                        <!---->
                        <?php
                        $sql = 'SELECT `*` FROM `Sightseeing` natural join `Township` WHERE `District`="基隆市" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="新北市" onmouseover="deepTaiwan(新北市)" onmouseout="normalTaiwan()">新北市
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="新北市" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="台北市" onmouseover="deepTaiwan(台北市)" onmouseout="normalTaiwan()">台北市
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="台北市" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="桃園市" onmouseover="deepTaiwan(桃園市)" onmouseout="normalTaiwan()">桃園市
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="桃園市" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="新竹縣" onmouseover="deepTaiwan(新竹縣)" onmouseout="normalTaiwan()">新竹縣
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="新竹縣" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="宜蘭縣" onmouseover="deepTaiwan(宜蘭縣)" onmouseout="normalTaiwan()">宜蘭縣
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="宜蘭縣" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
            </div>
            <!--中部(綠色區塊)-->
            <div class="midArea">
                <nav id="苗栗縣" onmouseover="deepTaiwan(苗栗縣)" onmouseout="normalTaiwan()">苗栗縣
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="苗栗縣" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?> </ul>
                </nav>
                <nav id="台中市" onmouseover="deepTaiwan(台中市)" onmouseout="normalTaiwan()">台中市
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="台中市" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");
                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="彰化縣" onmouseover="deepTaiwan(彰化縣)" onmouseout="normalTaiwan()">彰化縣
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="彰化縣" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="雲林縣" onmouseover="deepTaiwan(雲林縣)" onmouseout="normalTaiwan()">雲林縣
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="雲林縣" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="南投縣" onmouseover="deepTaiwan(南投縣)" onmouseout="normalTaiwan()">南投縣
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="南投縣" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="花蓮縣" onmouseover="deepTaiwan(花蓮縣)" onmouseout="normalTaiwan()">花蓮縣
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="花蓮縣" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
            </div>

            <!--南部(橘色區塊)-->
            <div class="southArea">
                <nav id="嘉義縣" onmouseover="deepTaiwan(嘉義縣)" onmouseout="normalTaiwan()">嘉義縣
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="嘉義縣" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="嘉義市" onmouseover="deepTaiwan(嘉義市)" onmouseout="normalTaiwan()">嘉義市
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="嘉義市" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="台南市" onmouseover="deepTaiwan(台南市)" onmouseout="normalTaiwan()">台南市
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="台南市" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="高雄市" onmouseover="deepTaiwan(高雄市)" onmouseout="normalTaiwan()">高雄市
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="高雄市" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="屏東縣" onmouseover="deepTaiwan(屏東縣)" onmouseout="normalTaiwan()">屏東縣
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="屏東縣" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
                <nav id="台東縣" onmouseover="deepTaiwan(台東縣)" onmouseout="normalTaiwan()">台東縣
                    <ul>
                        <?php
                        $sql = 'SELECT Attraction FROM Sightseeing natural join Township WHERE `District`="台東縣" ';
                        $result = mysqli_query($link, $sql) or die("fail sent");

                        if ($result) {
                            $num = mysqli_num_rows($result);                     #判斷資料表裡面有幾個資料
                        }
                        for ($i = 0; $i < $num; $i++) {
                            $row = mysqli_fetch_array($result);                  #存在一個陣列裡面(每做一次就會變成下一個row)
                            echo '<li><a href=""><input class="place" type="submit" name="place" value="' . $row['Attraction'] . '"></a></li>';
                        }
                        ?>
                    </ul>
                </nav>
            </div>
        </form>
    </div>
</div>