<?php
include("connect.php");

session_start();
$_SESSION['place'] = $_POST['place'];
$place = $_SESSION['place'];
$account = $_SESSION['account'];
?>

<!DOCTYPE html>
<html>

<head>
        <meta charset="utf-8">
        <title>返台。</title>
        <link rel="stylesheet" href="background.css">
        <script src="night_chooseAttraciton.js"></script>
        <script src="Game_question.js"></script>
</head>

<body>
        <div class="background">
                <?php
                include("notebook.php");
                ?>
                <div class="intro" id="intro">
                        <!--顯示景點名稱[Sightseeing(Attaction)]-->
                        <?php
                        $check = "SELECT * FROM Getattraction WHERE Account = '$account' AND Attraction='$place'"; //檢測是否已經拿過道具
                        $result1 = mysqli_query($link, $check); //執行sql
                        $rows = mysqli_num_rows($result1); //返回資料數(0或1)
                        if ($rows == 0) {                   //如果還去過此景點,就把它加進去Getattraction中
                                $sql = "INSERT INTO Getattraction(Account,Attraction) VALUES ('$account','$place')";
                                $result = mysqli_query($link, $sql) or die("fail sent");
                        }
                        echo '<p class="Attraction"> ' . $place . '</p>';             #存在一個陣列裡面(每做一次就會變成下一個row)
                        ?>


                        <div class="pic_background"></div>
                        <!--顯示背景圖片 [Sightseeing(Picture)]-->
                        <?php
                        $sql = "SELECT * FROM Sightseeing WHERE Attraction = '$place'";
                        $result = mysqli_query($link, $sql) or die("fail sent");
                        $row = mysqli_fetch_array($result);
                        echo '
                        <img src="image/picture/' . $row['Picture'] . '" class="backgroundImg">';
                        ?>
                        <div class="intro_pic" id="intro_pic" onclick="Question()">
                                <?php
                                $sql = "SELECT * FROM Sightseeing WHERE Attraction = '$place'";
                                $result = mysqli_query($link, $sql) or die("fail sent");
                                $row = mysqli_fetch_array($result);
                                echo '
                                                <img id="intro_pic" src="image/picture/' . $row['Picture'] . '">';
                                ?>
                                <!--顯示介紹圖片 [Sightseeing(Picture)]-->
                                <div class="word">
                                        <p id="intro_word_title">景點介紹:</p>
                                        <!--顯示景點介紹[Sightseeing(Description)]-->
                                        <?php
                                        $sql = "SELECT * From `Sightseeing` natural join Township  where `Attraction`= '$place'";
                                        $result = mysqli_query($link, $sql) or die("fail sent");
                                        $row = mysqli_fetch_array($result);
                                        echo '
                                                <p id="intro_word">' . $row['Description'] . '</p>
                                                <p></br></p>
                                                <p id="intro_word_title">景點地址:</p>
                                                <p id="intro_word">'.$row['District'].''.$row['Town'].'' . $row['Address'] . '</p>';
                                        ?>

                                        <!--顯示景點介紹[Sightseeing(Address)]-->
                                </div>
                        </div>
                </div>


                <div class="question" id="question">
                        <!--顯示第幾天[Userchoice(Day)]-->
                        <?php
                        echo '<p class="Attraction"> ' . $place . '</p>';             #存在一個陣列裡面(每做一次就會變成下一個row)
                        ?>

                        <div class="pic_background"></div>
                        <!--顯示背景圖片 [Sightseeing(Picture)]-->
                        <?php
                        $sql = "SELECT * FROM Sightseeing WHERE Attraction = '$place'";
                        $result = mysqli_query($link, $sql) or die("fail sent");
                        $row = mysqli_fetch_array($result);
                        echo '
                                <img src="image/picture/' . $row['Picture'] . '" class="backgroundImg">';
                        ?>

                        <div class="Question_G">
                                <?php
                                $sql = "SELECT * From Puzzle Where Attraction='$place'";
                                $result = mysqli_query($link, $sql) or die("fail sent");
                                $row = mysqli_fetch_array($result);
                                echo '<p id="Question">Q:' . $row['Question'] . '</p>
                                
                                <!--顯示3個答案[Puzzle(Option_1,Option2,Option3)]-->
                                <!--判斷 [Puzzle(Answer)] 哪一個是正解(假設A1為正解)-->
                                <form action="check_answer.php" method="post">
                                        <input class="answer1" type="submit" name="answer" value="1">
                                        <p id="Answer"> A1 : ' . $row['Option_1'] . '</p>
                                        <input class="answer2" type="submit" name="answer" value="2">
                                        <p id="Answer"> A2 : ' . $row['Option_2'] . '</p>
                                        <input class="answer3" type="submit" name="answer" value="3">
                                        <p id="Answer"> A3 : ' . $row['Option_3'] . '</p>
                                </form>';
                                ?>
                        </div>
                </div>
</body>

</html>