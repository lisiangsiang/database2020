<?php
include("connect.php");  //連結資料庫
session_start();
$account = $_SESSION['account'];      //post獲取表單裡的account

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>返台。</title>
    <link rel="stylesheet" href="background.css">
    <script src="night_chooseAttraciton.js"></script>
</head>

<body>
    <div class="background">

        <?php
        $sql1 = "SELECT * FROM Getattraction WHERE Account='$account'";
        $result1 = mysqli_query($link, $sql1) or die("fail sent");
        $totalGo_attraction = mysqli_num_rows($result1);                     #判斷資料表裡面有幾個資料


        $sql2 = "SELECT * FROM Sightseeing";
        $result2 = mysqli_query($link, $sql2) or die("fail sent");
        $totalattraction = mysqli_num_rows($result2);                         #判斷資料表裡面有幾個資料


        if ($totalGo_attraction < 3) {         #if ($totalGo_attraction<$totalattraction)
            include("taiwain.php");
        } else {

            $sql3 = "SELECT * FROM Getitem WHERE Account='$account'";
            $result3 = mysqli_query($link, $sql3) or die("fail sent");
            $totalitem = mysqli_num_rows($result3);

            echo '<script>console.log(' . $totalitem . ')</script>';

            if ($totalitem > $totalattraction) {
                header("Location:http://localhost/20200702/gameover(S).html");
                exit;
            } else {

                header("Location:http://localhost/20200702/gameover(F).html");
                exit;
            }
        }
        ?>
        <div style="position: relative; top:-100% ; left:0%">
            <?php
            include("notebook.php");
            ?>
        </div>

    </div>
</body>

</html>